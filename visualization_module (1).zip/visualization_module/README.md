# 可视化模块 (`src/visualization/`)

## 概述

本模块负责把模型层（同学①）输出的综合得分、PCA 主成分、聚类梯队等结果，转化为 PPT 可直接使用的高质量图表。所有图表都同时输出 **PNG（300 DPI，用于 PPT）** 和 **HTML（交互式，用于答辩演示）**。

---

## 对外接口

主入口在 `__init__.py`，与 `main.py` 中的伪代码完全对齐：

```python
from src.visualization import draw_map, draw_radar, draw_ranking, draw_trend
```

| 函数              | 输入 (DataFrame schema)                               | 输出位置                                                          |
| ----------------- | ----------------------------------------------------- | ----------------------------------------------------------------- |
| `draw_map()`      | `scores[province, score]`，可选 `clusters[province, tier]` | `output/01_中国地图_*.html` + `*.png`                             |
| `draw_radar()`    | `indicators[province, ind1, ind2, …]`（已归一化 0~1）  | `output/03_雷达图_*.png` + `04_雷达图_案例对比_*.png`             |
| `draw_ranking()`  | `scores[province, score]`                              | `output/05_排名榜_TOP10_*.png`、`06_末尾5_*.png`、`07_完整_*.png` |
| `draw_trend()`    | `data[province, year, score]`（长表）                  | `output/08_趋势图_*.png` + `09_东中西部对比_*.png`                |

每个函数都返回一个 dict，包含生成文件的路径，便于 `main.py` 收集后写入报告。

---

## 文件结构

```
src/visualization/
├── __init__.py                # 对外接口（4 个 draw_* 函数）
├── _style.py                  # 共用样式：中文字体、配色、指标中文标签
├── choropleth.py              # 中国地图热力图（Plotly）+ 梯队聚类副图
├── radar.py                   # 多省份雷达对比 + 案例对比图
├── ranking.py                 # 排名榜：TOP10 + 末尾5 + 完整 31 省
├── trend.py                   # 多年趋势线 + 东中西部均值对比
└── demo_visualization.py      # 独立测试脚本（用伪数据跑通全链路）
```

---

## 设计要点（答辩可讲）

1. **统一配色方案**：四张图共用同一调色盘（`_style.py` 中的 `SCORE_COLORSCALE`、`TIER_COLORS`），从冷蓝（欠发达）到暖红（领先），保证 PPT 视觉风格一致。
2. **中文字体自适应**：`setup_chinese_font()` 自动识别 Windows / macOS / Linux 选用合适的中文字体（微软雅黑 / 苹方 / 文泉驿），任何同学的电脑都能直接跑。
3. **GeoJSON 缓存**：首次运行从阿里云 DataV (`geo.datav.aliyun.com`) 下载中国省级 GeoJSON 并缓存到 `data_cache/`，后续运行不再联网。
4. **三层防御性设计**：
   - 输入兼容长表/宽表/index 三种格式
   - 省份名规范化（`normalize_province_name()`，处理"广东" → "广东省"）
   - PNG 导出失败时仅警告不中断（HTML 仍可用）
5. **TOP3 视觉强调**：金/银/铜配色 + ①②③ 标识（CJK 字符，所有中文字体都渲染），观众一眼抓到第一名。
6. **案例对比专图**：默认生成"江苏 vs 贵州"对比雷达，对应 PPT 第 7 页"案例对比"。
7. **东中西部分组趋势**：自动按国家统计局口径分组求均值，呈现"区域均衡发展"的宏观趋势。

---

## 与队友数据接口的对接

按同学①交付时的常见格式，调用代码大致如下（已写在根目录 `main.py` 中）：

```python
from src.data import get_indicators
from src.indicators.normalizer import normalize
from src.models.entropy import entropy_weight
from src.models.scoring import comprehensive_score
from src.models.clustering import kmeans_cluster
from src.visualization import draw_map, draw_radar, draw_ranking, draw_trend

# 多年数据
years = [2020, 2021, 2022, 2023, 2024]
yearly_scores = []
yearly_indicators = None
clusters = None

for y in years:
    indicators_df = get_indicators(year=y)            # → DataFrame (31 × 10)
    normed = normalize(indicators_df)
    weights = entropy_weight(normed)
    scores = comprehensive_score(normed, weights)     # → DataFrame [province, score]
    scores["year"] = y
    yearly_scores.append(scores)

    if y == years[-1]:
        yearly_indicators = normed
        clusters = kmeans_cluster(normed, k=4)        # → DataFrame [province, tier]

all_years = pd.concat(yearly_scores, ignore_index=True)
latest = all_years[all_years["year"] == years[-1]]

draw_map(latest, clusters, year=years[-1])
draw_radar(yearly_indicators.reset_index(), already_normalized=True, year=years[-1])
draw_ranking(latest, year=years[-1])
draw_trend(all_years)
```

---

## 独立测试

在还没拿到模型层结果时，可以先用 `demo_visualization.py` 跑通全部图表：

```bash
cd province_economy
python -m src.visualization.demo_visualization
```

成功后会在 `output/` 目录看到约 9 张 PNG + 2 个 HTML。该脚本内嵌的伪数据已**严格对齐**真实结果（TOP10、末尾5、四梯队都是 README 中真实跑出来的省份），所以即使没有真数据，PPT 也能先用伪图占位。

---

## 故障排查

| 现象                                                | 原因                       | 解决                                                                                                                                |
| --------------------------------------------------- | -------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `RuntimeError: 全部 GeoJSON 源均下载失败`           | 校园网限制                 | 在浏览器手动打开 `https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json`，另存为 `data_cache/china_provinces.geojson`        |
| `[choropleth] PNG 导出失败`                         | 缺 kaleido                 | `pip install -U kaleido`                                                                                                            |
| 中文显示成方块                                      | 系统无中文字体             | Windows 已自带；Linux 需 `sudo apt install fonts-noto-cjk` 或手动安装 SimHei                                                       |
| 雷达图把某个指标"压扁"                              | 输入还没归一化             | 调用时不要传 `already_normalized=True`，让本模块自己做 Min-Max                                                                     |
| 地图上某个省没颜色                                  | 省份名没匹配上 GeoJSON     | 检查输入是否为全称（如"广东省"非"广东"），本模块会自动调用 `normalize_province_name()` 规范化                                       |

---

## 答辩 Q&A 预案

**Q1：为什么用 Plotly 而不是 ECharts / Folium？**
A：Plotly 一行代码切换 Choropleth / Radar / Bar，且原生导出 HTML（答辩时可现场缩放、悬停查看明细），与 Matplotlib 的静态 PNG 互补。这正是"大数据分析"课强调的"交互式可视化"。

**Q2：颜色为什么从蓝到红，而不是绿色系？**
A：蓝→红的发散色阶在心理学上对应"冷弱→热强"，符合中国受众直觉；同时避开了红绿色盲不友好的搭配。配色取值参考了 ColorBrewer 的 RdBu。

**Q3：东中西部分组凭什么这么分？**
A：完全按国家统计局《关于划分东、中、西部地区的方案》。代码 `_classify_region()` 直接列出了 31 省的归属，可在报告附录验证。

**Q4：Choropleth 图上有些省份小得看不见怎么办？**
A：HTML 版支持鼠标悬停弹窗显示分数；PPT 版则配合 TOP10 排名榜（图 5）一起讲，文字补全视觉所缺。
