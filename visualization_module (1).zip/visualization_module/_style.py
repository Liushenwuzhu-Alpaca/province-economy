"""
可视化通用工具：中文字体、配色方案、指标中文标签、输出路径
所有四个绘图模块共用这里的样式，保证 PPT 中风格统一。
"""

from __future__ import annotations

import os
import platform
from pathlib import Path
from typing import Iterable

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import font_manager


# ---------------------------------------------------------------------------
# 1. 中文字体设置
# ---------------------------------------------------------------------------

def setup_chinese_font() -> None:
    """根据操作系统自动设置 matplotlib 的中文字体。

    Windows 用 SimHei / 微软雅黑，macOS 用苹方，Linux 用文泉驿或思源黑体。
    若都找不到则保持默认（绘图中的中文会变方块，需自行安装字体）。
    """
    system = platform.system()
    if system == "Windows":
        candidates = ["Microsoft YaHei", "SimHei", "SimSun"]
    elif system == "Darwin":
        candidates = ["PingFang SC", "Heiti SC", "Hiragino Sans GB", "Arial Unicode MS"]
    else:  # Linux / 其他
        candidates = [
            "Noto Sans CJK SC",
            "WenQuanYi Micro Hei",
            "WenQuanYi Zen Hei",
            "Source Han Sans CN",
            "SimHei",
        ]

    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((c for c in candidates if c in available), None)

    if chosen:
        plt.rcParams["font.sans-serif"] = [chosen] + plt.rcParams["font.sans-serif"]
    else:
        # 至少把候选放进去，让 matplotlib 自己尝试
        plt.rcParams["font.sans-serif"] = candidates + plt.rcParams["font.sans-serif"]

    plt.rcParams["axes.unicode_minus"] = False  # 修复负号显示
    plt.rcParams["figure.dpi"] = 110
    plt.rcParams["savefig.dpi"] = 300
    plt.rcParams["savefig.bbox"] = "tight"


# ---------------------------------------------------------------------------
# 2. 配色方案（与 PPT 主色调统一）
# ---------------------------------------------------------------------------

# 主色调：从冷到暖的渐变，对应得分由低到高
SCORE_COLORSCALE = [
    [0.00, "#2c5f8d"],   # 深蓝 — 欠发达
    [0.25, "#7fb2d8"],   # 浅蓝
    [0.50, "#f4e8c1"],   # 米黄 — 中等
    [0.75, "#e89c5f"],   # 橙
    [1.00, "#b8311a"],   # 深红 — 领先
]

# 四梯队配色（与聚类结果对应）
TIER_COLORS = {
    "第一梯队": "#b8311a",
    "第二梯队": "#e89c5f",
    "第三梯队": "#7fb2d8",
    "第四梯队": "#2c5f8d",
}

# TOP 排名榜配色：金银铜 + 普通
RANK_GOLD = "#d4af37"
RANK_SILVER = "#c0c0c0"
RANK_BRONZE = "#cd7f32"
RANK_NORMAL = "#4a7ab8"

# 雷达图与趋势图的多省份配色
PROVINCE_PALETTE = [
    "#b8311a",   # 红
    "#e89c5f",   # 橙
    "#4a7ab8",   # 蓝
    "#5b8c5a",   # 绿
    "#8e5a9b",   # 紫
    "#c0793e",   # 棕
    "#3d8e8e",   # 青
    "#a83279",   # 玫红
]


# ---------------------------------------------------------------------------
# 3. 指标 → 中文标签映射（与 config.ANALYSIS_INDICATORS 一致）
# ---------------------------------------------------------------------------

INDICATOR_LABELS_CN = {
    "gdp": "GDP总量",
    "gdp_growth": "GDP增速",
    "retail": "社零总额",
    "income": "人均可支配收入",
    "consumption_expenditure": "人均消费支出",
    "tertiary_share": "第三产业占比",
    "fixed_invest": "固定资产投资",
    "fiscal_revenue": "财政收入",
    "cpi": "CPI",
    "unemployment": "失业率",
    # 备用（旧版方案中的指标，万一指标体系调整后仍兼容）
    "per_capita_gdp": "人均GDP",
    "urbanization": "城镇化率",
    "population_growth": "常住人口增速",
    "education_per_capita": "人均教育经费",
    "tech_market": "技术市场成交额",
    "patents_per_10k": "每万人专利",
}


def label_of(indicator: str) -> str:
    """获取指标的中文显示标签，未登记的直接返回原名。"""
    return INDICATOR_LABELS_CN.get(indicator, indicator)


# ---------------------------------------------------------------------------
# 4. 输出目录
# ---------------------------------------------------------------------------

DEFAULT_OUTPUT_DIR = Path("output")


def ensure_output_dir(output_dir: str | os.PathLike | None = None) -> Path:
    """确保输出目录存在并返回 Path 对象。"""
    path = Path(output_dir) if output_dir else DEFAULT_OUTPUT_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


# ---------------------------------------------------------------------------
# 5. 省份名规范化（GeoJSON 里有时简写）
# ---------------------------------------------------------------------------

# 数据 → GeoJSON 中名称的对照表（DataV 的 geojson 用全称）
PROVINCE_NAME_MAP = {
    "北京": "北京市",
    "上海": "上海市",
    "天津": "天津市",
    "重庆": "重庆市",
    "河北": "河北省",
    "山西": "山西省",
    "辽宁": "辽宁省",
    "吉林": "吉林省",
    "黑龙江": "黑龙江省",
    "江苏": "江苏省",
    "浙江": "浙江省",
    "安徽": "安徽省",
    "福建": "福建省",
    "江西": "江西省",
    "山东": "山东省",
    "河南": "河南省",
    "湖北": "湖北省",
    "湖南": "湖南省",
    "广东": "广东省",
    "海南": "海南省",
    "四川": "四川省",
    "贵州": "贵州省",
    "云南": "云南省",
    "陕西": "陕西省",
    "甘肃": "甘肃省",
    "青海": "青海省",
    "台湾": "台湾省",
    "内蒙古": "内蒙古自治区",
    "广西": "广西壮族自治区",
    "西藏": "西藏自治区",
    "宁夏": "宁夏回族自治区",
    "新疆": "新疆维吾尔自治区",
    "香港": "香港特别行政区",
    "澳门": "澳门特别行政区",
}


def normalize_province_name(name: str) -> str:
    """统一为 DataV GeoJSON 中使用的省级行政区全称。"""
    if not isinstance(name, str):
        return name
    name = name.strip()
    return PROVINCE_NAME_MAP.get(name, name)
