"""
choropleth.py — 中国省域综合得分热力图

核心可视化：用中国地图直观展示 31 省的综合竞争力得分。
- 颜色越深表示综合得分越高（深红 = 领先，深蓝 = 欠发达）
- 同时输出 HTML（交互式，可悬停查看明细）和 PNG（静态，用于 PPT）

数据来源：阿里云 DataV 提供的全国省级行政区 GeoJSON
    https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional
import urllib.request

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from ._style import (
    DEFAULT_OUTPUT_DIR,
    SCORE_COLORSCALE,
    TIER_COLORS,
    ensure_output_dir,
    normalize_province_name,
)


# ---------------------------------------------------------------------------
# GeoJSON 加载（带本地缓存，避免重复下载）
# ---------------------------------------------------------------------------

GEOJSON_URLS = [
    # 主源：阿里云 DataV（国内访问最稳）
    "https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json",
    # 备用：GitHub 镜像
    "https://raw.githubusercontent.com/Plortinus/china-geojson/master/china.json",
]
GEOJSON_CACHE = Path("data_cache") / "china_provinces.geojson"

_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)


def _load_china_geojson() -> dict:
    """加载中国省级 GeoJSON，优先用本地缓存。"""
    GEOJSON_CACHE.parent.mkdir(parents=True, exist_ok=True)

    if GEOJSON_CACHE.exists():
        with open(GEOJSON_CACHE, "r", encoding="utf-8") as f:
            return json.load(f)

    print("[choropleth] 首次运行，正在下载中国省级 GeoJSON ...")
    last_err: Optional[Exception] = None
    for url in GEOJSON_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _BROWSER_UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            with open(GEOJSON_CACHE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            print(f"[choropleth] 已缓存到 {GEOJSON_CACHE}  (来源: {url})")
            return data
        except Exception as e:
            print(f"[choropleth] 下载失败 ({url}): {e}")
            last_err = e

    raise RuntimeError(
        f"全部 GeoJSON 源均下载失败，最后一个错误: {last_err}\n"
        f"请手动下载 {GEOJSON_URLS[0]} 到 {GEOJSON_CACHE}"
    )


# ---------------------------------------------------------------------------
# 主函数
# ---------------------------------------------------------------------------

def draw_map(
    scores: pd.DataFrame,
    clusters: Optional[pd.DataFrame] = None,
    *,
    province_col: str = "province",
    score_col: str = "score",
    tier_col: str = "tier",
    output_dir: os.PathLike | str | None = None,
    title: str = "中国省域经济综合竞争力 — 综合得分热力图",
    year: Optional[int] = None,
    save_png: bool = True,
) -> dict:
    """绘制中国省域综合得分热力地图。

    Parameters
    ----------
    scores : pd.DataFrame
        必含两列 — 省份名（与 config.PROVINCES 一致）和综合得分（0~100）。
        可以是模型层 ``comprehensive_score()`` 的直接输出。
    clusters : pd.DataFrame, optional
        聚类结果，含省份名和梯队列；若提供，会额外生成一张梯队着色图。
    province_col, score_col, tier_col : str
        指定列名，便于不同命名风格的 DataFrame 接入。
    output_dir : path-like, optional
        输出目录，默认为 ``output/``。
    title : str
        图表主标题。
    year : int, optional
        年份，会拼到标题里，便于多年份对比时区分文件名。
    save_png : bool
        是否同时保存 PNG（需安装 ``kaleido``）。

    Returns
    -------
    dict
        {"html": Path, "png": Path|None, "tier_html": Path|None, "tier_png": Path|None}
    """
    out_dir = ensure_output_dir(output_dir)
    suffix = f"_{year}" if year else ""

    # 1) 数据预处理 ---------------------------------------------------------
    df = scores.copy()
    if province_col not in df.columns and df.index.name in ("province", "省份"):
        df = df.reset_index().rename(columns={df.index.name: province_col})

    df[province_col] = df[province_col].map(normalize_province_name)

    # 2) GeoJSON ------------------------------------------------------------
    geojson = _load_china_geojson()

    # 3) 主图：得分热力图 ---------------------------------------------------
    fig = px.choropleth(
        df,
        geojson=geojson,
        featureidkey="properties.name",
        locations=province_col,
        color=score_col,
        color_continuous_scale=SCORE_COLORSCALE,
        range_color=(0, 100),
        labels={score_col: "综合得分"},
        hover_name=province_col,
        hover_data={score_col: ":.2f", province_col: False},
    )

    fig.update_geos(
        fitbounds="locations",
        visible=False,
        projection_type="mercator",
    )
    fig.update_layout(
        title=dict(text=title, x=0.5, xanchor="center", font=dict(size=20)),
        margin=dict(l=0, r=0, t=60, b=0),
        coloraxis_colorbar=dict(
            title="得分",
            ticksuffix=" 分",
            len=0.7,
            thickness=18,
        ),
        font=dict(family="Microsoft YaHei, SimHei, PingFang SC, sans-serif"),
    )

    html_path = out_dir / f"01_中国地图_综合得分热力图{suffix}.html"
    fig.write_html(str(html_path), include_plotlyjs="cdn")
    print(f"[choropleth] HTML 已生成: {html_path}")

    png_path = None
    if save_png:
        png_path = out_dir / f"01_中国地图_综合得分热力图{suffix}.png"
        try:
            fig.write_image(str(png_path), width=1400, height=900, scale=2)
            print(f"[choropleth] PNG 已生成: {png_path}")
        except Exception as e:
            print(f"[choropleth] PNG 导出失败（可忽略，HTML 已生成）: {e}")
            print("           若需 PNG，请运行: pip install -U kaleido")
            png_path = None

    result = {"html": html_path, "png": png_path, "tier_html": None, "tier_png": None}

    # 4) 副图：梯队分类地图（若提供 clusters） -----------------------------
    if clusters is not None:
        tier_df = clusters.copy()
        if province_col not in tier_df.columns and tier_df.index.name in ("province", "省份"):
            tier_df = tier_df.reset_index().rename(columns={tier_df.index.name: province_col})
        tier_df[province_col] = tier_df[province_col].map(normalize_province_name)

        # 确定 tier 列的标签（处理整数索引或中文名两种情况）
        if tier_df[tier_col].dtype.kind in "iuf":
            tier_label_map = {
                0: "第一梯队", 1: "第二梯队", 2: "第三梯队", 3: "第四梯队", 4: "第五梯队",
            }
            # 默认按梯队号 0..n 已经从领先到追赶；若反了请在外层转换
            tier_df["__tier_label__"] = tier_df[tier_col].map(tier_label_map)
            label_col = "__tier_label__"
        else:
            label_col = tier_col

        # 保留梯队顺序，让图例颜色一致
        category_order = ["第一梯队", "第二梯队", "第三梯队", "第四梯队", "第五梯队"]
        present = [c for c in category_order if c in tier_df[label_col].unique()]

        fig2 = px.choropleth(
            tier_df,
            geojson=geojson,
            featureidkey="properties.name",
            locations=province_col,
            color=label_col,
            category_orders={label_col: present},
            color_discrete_map=TIER_COLORS,
            labels={label_col: "梯队"},
            hover_name=province_col,
        )
        fig2.update_geos(fitbounds="locations", visible=False, projection_type="mercator")
        fig2.update_layout(
            title=dict(
                text=f"中国省域经济竞争力 — 四梯队聚类分布{('  '+str(year)+'年') if year else ''}",
                x=0.5, xanchor="center", font=dict(size=20),
            ),
            margin=dict(l=0, r=0, t=60, b=0),
            legend=dict(title="梯队", orientation="v", x=1.0, y=0.5),
            font=dict(family="Microsoft YaHei, SimHei, PingFang SC, sans-serif"),
        )

        tier_html = out_dir / f"02_中国地图_聚类梯队分布{suffix}.html"
        fig2.write_html(str(tier_html), include_plotlyjs="cdn")
        result["tier_html"] = tier_html
        print(f"[choropleth] 梯队 HTML 已生成: {tier_html}")

        if save_png:
            tier_png = out_dir / f"02_中国地图_聚类梯队分布{suffix}.png"
            try:
                fig2.write_image(str(tier_png), width=1400, height=900, scale=2)
                result["tier_png"] = tier_png
                print(f"[choropleth] 梯队 PNG 已生成: {tier_png}")
            except Exception:
                pass

    return result


if __name__ == "__main__":
    # 自测：用伪数据跑一遍，验证函数和 GeoJSON 对接是否正常
    import numpy as np
    rng = np.random.default_rng(42)
    provinces = [
        "北京市","天津市","河北省","山西省","内蒙古自治区","辽宁省","吉林省","黑龙江省",
        "上海市","江苏省","浙江省","安徽省","福建省","江西省","山东省","河南省","湖北省",
        "湖南省","广东省","广西壮族自治区","海南省","重庆市","四川省","贵州省","云南省",
        "西藏自治区","陕西省","甘肃省","青海省","宁夏回族自治区","新疆维吾尔自治区",
    ]
    fake_scores = pd.DataFrame({
        "province": provinces,
        "score": rng.uniform(10, 100, size=len(provinces)).round(2),
    })
    draw_map(fake_scores, year=2024)
