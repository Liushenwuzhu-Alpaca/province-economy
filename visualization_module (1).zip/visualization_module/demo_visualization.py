"""
demo_visualization.py — 可视化模块独立演示脚本

⚠️ 这个文件只用于联调阶段：在 ML 同学还没交付真实数据前，
   用本文件嵌入的"伪造但合理"的数据先把四张图跑出来，
   验证字体、地图、雷达、排名、趋势全链路 OK。

使用方法：
    cd province_economy
    python -m src.visualization.demo_visualization

成功后会在 output/ 目录下看到约 9 张 png + 2 个 html。
等同学 ① 交付真实 scores 后，把本文件里的 fake_* DataFrame 替换为
真实数据即可。或者直接调用根目录的 main.py（流程已串联）。
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.visualization import draw_map, draw_radar, draw_ranking, draw_trend


# ---------------------------------------------------------------------------
# 31 省名称（与 GeoJSON 的全称一致）
# ---------------------------------------------------------------------------
PROVINCES = [
    "北京市", "天津市", "河北省", "山西省", "内蒙古自治区",
    "辽宁省", "吉林省", "黑龙江省",
    "上海市", "江苏省", "浙江省", "安徽省", "福建省", "江西省",
    "山东省", "河南省", "湖北省", "湖南省",
    "广东省", "广西壮族自治区", "海南省",
    "重庆市", "四川省", "贵州省", "云南省", "西藏自治区",
    "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区",
]

INDICATORS = [
    "gdp", "gdp_growth", "retail", "income", "consumption_expenditure",
    "tertiary_share", "fixed_invest", "fiscal_revenue", "cpi", "unemployment",
]


# ---------------------------------------------------------------------------
# 模拟"模型层"输出 —— 与同学 ① 真实交付时的数据 schema 完全一致
# ---------------------------------------------------------------------------

def fake_scores_2024() -> pd.DataFrame:
    """与 main.py 实际跑出来的 TOP10 / 末尾5 一致的伪 31 省得分。"""
    real_top = [
        ("广东省", 100.00), ("上海市", 96.75), ("北京市", 87.65),
        ("浙江省", 86.27), ("江苏省", 80.94), ("山东省", 67.31),
        ("福建省", 58.14), ("四川省", 56.16), ("湖北省", 43.39),
        ("河南省", 40.52),
    ]
    real_bottom = [
        ("新疆维吾尔自治区", 15.21), ("宁夏回族自治区", 12.80),
        ("甘肃省", 10.93), ("黑龙江省", 9.29), ("青海省", 0.00),
    ]
    used = {p for p, _ in real_top + real_bottom}
    middle = [p for p in PROVINCES if p not in used]
    rng = np.random.default_rng(2024)
    middle_scores = sorted(rng.uniform(15.5, 40, size=len(middle)), reverse=True)
    middle_pairs = list(zip(middle, middle_scores))

    rows = real_top + middle_pairs + real_bottom
    df = pd.DataFrame(rows, columns=["province", "score"])
    return df


def fake_clusters_2024() -> pd.DataFrame:
    """与 README 中"梯队分布"一致的聚类结果。"""
    tier1 = ["北京市", "上海市"]
    tier2 = ["江苏省", "浙江省", "山东省", "广东省"]
    tier3 = ["河北省", "辽宁省", "安徽省", "福建省", "江西省", "河南省",
             "湖北省", "湖南省", "重庆市", "四川省", "陕西省"]
    tier4 = ["天津市", "山西省", "内蒙古自治区", "吉林省", "黑龙江省",
             "广西壮族自治区", "海南省", "贵州省", "云南省", "西藏自治区",
             "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区"]
    rows = (
        [(p, "第一梯队") for p in tier1]
        + [(p, "第二梯队") for p in tier2]
        + [(p, "第三梯队") for p in tier3]
        + [(p, "第四梯队") for p in tier4]
    )
    return pd.DataFrame(rows, columns=["province", "tier"])


def fake_indicators_2024() -> pd.DataFrame:
    """模拟标准化后的指标矩阵：得分高的省整体优秀，得分低的整体偏弱。"""
    scores = fake_scores_2024().set_index("province")["score"]
    rng = np.random.default_rng(42)

    rows = []
    for province, total_score in scores.items():
        base = total_score / 100.0  # 0~1
        row = {"province": province}
        for ind in INDICATORS:
            # 加噪声让雷达图有"个性"
            noise = rng.normal(0, 0.12)
            value = np.clip(base + noise, 0.02, 1.0)
            # CPI、失业率、增速等指标人为反向波动一点
            if ind in ("cpi", "unemployment"):
                value = np.clip(0.5 + rng.normal(0, 0.18), 0.05, 0.95)
            elif ind == "gdp_growth":
                value = np.clip(0.5 + rng.normal(0, 0.2), 0.05, 0.95)
            row[ind] = round(value, 4)
        rows.append(row)
    return pd.DataFrame(rows)


def fake_yearly_scores() -> pd.DataFrame:
    """模拟 2020-2024 五年得分趋势，长表格式 (province, year, score)。"""
    rng = np.random.default_rng(123)
    base = fake_scores_2024().set_index("province")["score"]
    rows = []
    for province, latest in base.items():
        # 反推 5 年趋势：让最新一年=latest，往前每年加噪声
        trajectory_noise = rng.normal(0, 4)
        for i, year in enumerate([2020, 2021, 2022, 2023, 2024]):
            offset = (4 - i) * rng.uniform(-1.5, 1.5) + trajectory_noise * (4 - i) / 4
            score = max(0.0, min(100.0, latest - offset))
            rows.append({"province": province, "year": year, "score": round(score, 2)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def main():
    print("=" * 60)
    print("  可视化模块独立演示  (年份: 2024)")
    print("=" * 60)

    scores = fake_scores_2024()
    clusters = fake_clusters_2024()
    indicators = fake_indicators_2024()
    yearly = fake_yearly_scores()

    print(f"\n[demo] 已加载伪数据: {len(scores)} 省 × {len(INDICATORS)} 指标 × 5 年")

    # 1) 中国地图（含梯队副图）
    print("\n[1/4] 中国地图热力图 ...")
    draw_map(scores, clusters, year=2024)

    # 2) 雷达图（主图 + 案例对比）
    print("\n[2/4] 省份雷达图 ...")
    draw_radar(indicators, already_normalized=True, year=2024)

    # 3) 排名榜
    print("\n[3/4] TOP10 排名榜 ...")
    draw_ranking(scores, year=2024)

    # 4) 趋势图
    print("\n[4/4] 多年趋势图 ...")
    draw_trend(yearly)

    print("\n" + "=" * 60)
    print("  全部图表已生成，请查看 output/ 目录")
    print("=" * 60)


if __name__ == "__main__":
    main()
