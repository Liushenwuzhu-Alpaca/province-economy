"""
radar.py — 省份多维雷达图

用雷达图直观对比若干典型省份在不同指标上的优劣。
默认对比"京沪粤苏浙"五大经济强省，也可在调用时传入 ``provinces`` 参数自定义。

设计要点：
- 所有指标都被标准化到 0~1，使不同量纲在同一张图上可比
- 多个省份用半透明填充叠加，便于一眼看出"全面发达"还是"单项突出"
- PPT 演示常用：东部 vs 西部、案例对比（如江苏 vs 贵州）
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Optional, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ._style import (
    PROVINCE_PALETTE,
    ensure_output_dir,
    label_of,
    setup_chinese_font,
)


def _minmax_normalize(df: pd.DataFrame) -> pd.DataFrame:
    """对每列做 Min-Max 归一化到 [0, 1]，避免雷达图被某个大量纲指标挤压。"""
    out = df.copy().astype(float)
    for col in out.columns:
        col_min, col_max = out[col].min(), out[col].max()
        if col_max - col_min > 1e-12:
            out[col] = (out[col] - col_min) / (col_max - col_min)
        else:
            out[col] = 0.5
    return out


def draw_radar(
    indicators: pd.DataFrame,
    provinces: Optional[Sequence[str]] = None,
    *,
    province_col: str = "province",
    indicator_cols: Optional[Sequence[str]] = None,
    output_dir: os.PathLike | str | None = None,
    title: str = "典型省份多维指标雷达图",
    year: Optional[int] = None,
    already_normalized: bool = False,
    case_pair: Optional[tuple[str, str]] = ("江苏省", "贵州省"),
) -> dict:
    """绘制省份雷达对比图。

    Parameters
    ----------
    indicators : pd.DataFrame
        指标数据，可以是：
          a) 含一个 ``province`` 列 + 各指标列；
          b) 以省份为 index，列为各指标。
    provinces : list[str], optional
        要展示的省份。默认 ['北京市', '上海市', '广东省', '江苏省', '浙江省']。
    indicator_cols : list[str], optional
        指标列名。默认使用所有非省份列。
    already_normalized : bool
        若 True，跳过 Min-Max 归一化（你们模型层若已交付归一化数据可省一步）。
    case_pair : tuple[str, str], optional
        除主图外，额外生成一张"案例对比图"。默认江苏 vs 贵州（PPT 第 7 页）。
        传 None 关闭。

    Returns
    -------
    dict
        {"main_png": Path, "case_png": Path|None}
    """
    setup_chinese_font()
    out_dir = ensure_output_dir(output_dir)
    suffix = f"_{year}" if year else ""

    # 1) 标准化输入 ---------------------------------------------------------
    df = indicators.copy()
    if province_col in df.columns:
        df = df.set_index(province_col)
    df.index = df.index.astype(str)

    if indicator_cols is None:
        indicator_cols = [c for c in df.columns if c != province_col]
    df = df[list(indicator_cols)]

    if not already_normalized:
        df = _minmax_normalize(df)

    if provinces is None:
        provinces = ["北京市", "上海市", "广东省", "江苏省", "浙江省"]

    missing = [p for p in provinces if p not in df.index]
    if missing:
        print(f"[radar] 警告：以下省份在数据中找不到，已跳过 -> {missing}")
    provinces = [p for p in provinces if p in df.index]
    if not provinces:
        raise ValueError("传入的 provinces 与数据均不匹配，无法绘图。")

    # 2) 主图：多省份雷达图 -------------------------------------------------
    main_png = _plot_radar(
        df.loc[provinces, :],
        indicator_cols,
        title=f"{title}{('  '+str(year)+'年') if year else ''}",
        save_path=out_dir / f"03_雷达图_{'_'.join(provinces[:5])}{suffix}.png",
    )

    # 3) 副图：案例对比 -----------------------------------------------------
    case_png = None
    if case_pair is not None:
        a, b = case_pair
        if a in df.index and b in df.index:
            case_png = _plot_radar(
                df.loc[[a, b], :],
                indicator_cols,
                title=f"案例对比：{a} vs {b}{('  '+str(year)+'年') if year else ''}",
                save_path=out_dir / f"04_雷达图_案例对比_{a}_vs_{b}{suffix}.png",
                colors=["#b8311a", "#4a7ab8"],
            )
        else:
            print(f"[radar] 案例对比省份缺失 ({a}, {b})，跳过案例图")

    return {"main_png": main_png, "case_png": case_png}


def _plot_radar(
    sub_df: pd.DataFrame,
    indicators: Sequence[str],
    *,
    title: str,
    save_path: Path,
    colors: Optional[Sequence[str]] = None,
) -> Path:
    """实际渲染雷达图的内部函数。"""
    labels = [label_of(c) for c in indicators]
    N = len(labels)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]  # 闭合

    fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))
    palette = list(colors) if colors else PROVINCE_PALETTE

    for i, province in enumerate(sub_df.index):
        values = sub_df.loc[province, list(indicators)].tolist()
        values += values[:1]
        color = palette[i % len(palette)]
        ax.plot(angles, values, linewidth=2.2, label=province, color=color)
        ax.fill(angles, values, alpha=0.18, color=color)

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, fontsize=12)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(["0.2", "0.4", "0.6", "0.8", "1.0"], color="grey", fontsize=9)
    ax.set_ylim(0, 1.0)
    ax.grid(alpha=0.4)
    ax.spines["polar"].set_alpha(0.35)

    ax.set_title(title, size=16, weight="bold", pad=24)
    ax.legend(
        loc="upper right",
        bbox_to_anchor=(1.28, 1.05),
        fontsize=11,
        frameon=True,
        framealpha=0.85,
    )

    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close(fig)
    print(f"[radar] PNG 已生成: {save_path}")
    return save_path


if __name__ == "__main__":
    # 自测
    rng = np.random.default_rng(7)
    provinces_full = [
        "北京市", "上海市", "广东省", "江苏省", "浙江省", "山东省", "贵州省", "青海省",
    ]
    indicators_demo = [
        "gdp", "gdp_growth", "retail", "income", "consumption_expenditure",
        "tertiary_share", "fixed_invest", "fiscal_revenue", "cpi", "unemployment",
    ]
    fake = pd.DataFrame(
        rng.uniform(0.1, 1.0, size=(len(provinces_full), len(indicators_demo))),
        index=provinces_full, columns=indicators_demo,
    )
    fake.index.name = "province"
    draw_radar(fake.reset_index(), already_normalized=True, year=2024)
