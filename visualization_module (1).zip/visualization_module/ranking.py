"""
ranking.py — TOP10 综合得分排名榜

水平柱状图，从上到下排名递减。前三名特别用金、银、铜色突出。
PPT 上观众最喜欢看排行榜，这是引发现场讨论的关键页。

附加功能：
- 自动在每个柱子末尾标注分数
- 可选择同时输出"末尾 5 名"作为对照
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ._style import (
    RANK_BRONZE,
    RANK_GOLD,
    RANK_NORMAL,
    RANK_SILVER,
    ensure_output_dir,
    setup_chinese_font,
)


def draw_ranking(
    scores: pd.DataFrame,
    *,
    province_col: str = "province",
    score_col: str = "score",
    top_n: int = 10,
    output_dir: os.PathLike | str | None = None,
    title: str = "省域经济综合竞争力 TOP {n}",
    year: Optional[int] = None,
    show_bottom: bool = True,
) -> dict:
    """绘制 TOP N 排名榜（水平柱状图）。

    Parameters
    ----------
    scores : pd.DataFrame
        含省份名和综合得分两列。
    top_n : int
        展示前 N 名，默认 10。
    show_bottom : bool
        是否同时绘制后 5 名，便于报告里做对比。

    Returns
    -------
    dict
        {"top_png": Path, "bottom_png": Path|None, "full_png": Path}
    """
    setup_chinese_font()
    out_dir = ensure_output_dir(output_dir)
    suffix = f"_{year}" if year else ""

    df = scores.copy()
    if province_col not in df.columns and df.index.name in ("province", "省份"):
        df = df.reset_index().rename(columns={df.index.name: province_col})
    df = df[[province_col, score_col]].dropna()
    df = df.sort_values(score_col, ascending=False).reset_index(drop=True)

    # ---- 主图：TOP N -----------------------------------------------------
    top_df = df.head(top_n).copy()
    top_png = _plot_horizontal_ranking(
        top_df,
        province_col,
        score_col,
        title=title.format(n=top_n) + (f"  {year}年" if year else ""),
        save_path=out_dir / f"05_排名榜_TOP{top_n}{suffix}.png",
        highlight_top3=True,
    )

    # ---- 副图：末尾 5 名 -------------------------------------------------
    bottom_png = None
    if show_bottom and len(df) > top_n + 5:
        bottom_df = df.tail(5).copy()
        bottom_df = bottom_df.iloc[::-1].reset_index(drop=True)  # 倒序，让最低名在最下面
        bottom_df = bottom_df.iloc[::-1].reset_index(drop=True)  # 实际想要分数从高到低
        bottom_df = df.tail(5).sort_values(score_col, ascending=True).reset_index(drop=True)
        bottom_png = _plot_horizontal_ranking(
            bottom_df,
            province_col,
            score_col,
            title=f"末尾 5 名 — 待振兴地区{(' '+str(year)+'年') if year else ''}",
            save_path=out_dir / f"06_排名榜_末尾5{suffix}.png",
            highlight_top3=False,
            color_override="#7a7a7a",
        )

    # ---- 全榜：31 省 ------------------------------------------------------
    full_png = _plot_horizontal_ranking(
        df.copy(),
        province_col,
        score_col,
        title=f"31 省综合竞争力完整排名{(' '+str(year)+'年') if year else ''}",
        save_path=out_dir / f"07_排名榜_完整{suffix}.png",
        highlight_top3=True,
        compact=True,
    )

    return {"top_png": top_png, "bottom_png": bottom_png, "full_png": full_png}


def _plot_horizontal_ranking(
    df: pd.DataFrame,
    province_col: str,
    score_col: str,
    *,
    title: str,
    save_path: Path,
    highlight_top3: bool = True,
    color_override: Optional[str] = None,
    compact: bool = False,
) -> Path:
    """实际渲染水平柱状图。"""
    n = len(df)
    fig_height = max(4.5, 0.45 * n + 1.5) if not compact else max(7, 0.32 * n + 1.5)
    fig, ax = plt.subplots(figsize=(11, fig_height))

    # 倒序后，第 1 名出现在最上面
    df_plot = df.iloc[::-1].reset_index(drop=True)
    n = len(df_plot)

    # 配色
    if color_override:
        colors = [color_override] * n
    elif highlight_top3:
        colors = []
        for i in range(n):
            rank = n - i  # 从下往上的真实排名
            if rank == 1:
                colors.append(RANK_GOLD)
            elif rank == 2:
                colors.append(RANK_SILVER)
            elif rank == 3:
                colors.append(RANK_BRONZE)
            else:
                colors.append(RANK_NORMAL)
    else:
        colors = [RANK_NORMAL] * n

    bars = ax.barh(
        df_plot[province_col],
        df_plot[score_col],
        color=colors,
        edgecolor="white",
        linewidth=0.6,
    )

    # 标注分数
    max_score = df_plot[score_col].max()
    for bar, score in zip(bars, df_plot[score_col]):
        ax.text(
            bar.get_width() + max_score * 0.01,
            bar.get_y() + bar.get_height() / 2,
            f"{score:.2f}",
            ha="left",
            va="center",
            fontsize=9 if compact else 10,
            color="#333",
        )

    # 给 TOP 3 加奖牌符号（用 CJK 圆圈数字，所有中文字体都支持）
    if highlight_top3:
        medals = {n - 1: ("①", RANK_GOLD), n - 2: ("②", RANK_SILVER), n - 3: ("③", RANK_BRONZE)}
        # 使用 axes coordinates 画在 y 轴左侧空白处
        from matplotlib.transforms import blended_transform_factory
        trans = blended_transform_factory(ax.transAxes, ax.transData)
        for idx, (mark, mc) in medals.items():
            if 0 <= idx < n:
                ax.text(
                    -0.085 if not compact else -0.06,
                    idx,
                    mark,
                    ha="center",
                    va="center",
                    fontsize=18 if compact else 22,
                    weight="bold",
                    color=mc,
                    transform=trans,
                    clip_on=False,
                )

    ax.set_xlabel("综合得分", fontsize=12)
    ax.set_xlim(0, max_score * 1.13)
    ax.set_title(title, fontsize=15, weight="bold", pad=15)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines["left"].set_color("#cccccc")
    ax.spines["bottom"].set_color("#cccccc")
    ax.tick_params(axis="y", length=0, labelsize=10 if compact else 11)
    ax.tick_params(axis="x", labelsize=10)
    ax.grid(axis="x", alpha=0.3, linestyle="--")
    ax.set_axisbelow(True)

    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close(fig)
    print(f"[ranking] PNG 已生成: {save_path}")
    return save_path


if __name__ == "__main__":
    # 用 README 中给出的真实结果做自测
    fake = pd.DataFrame({
        "province": [
            "广东省", "上海市", "北京市", "浙江省", "江苏省",
            "山东省", "福建省", "四川省", "湖北省", "河南省",
            "湖南省", "安徽省", "重庆市", "陕西省", "辽宁省",
            "江西省", "河北省", "云南省", "内蒙古自治区", "广西壮族自治区",
            "山西省", "贵州省", "天津市", "海南省", "吉林省",
            "西藏自治区", "新疆维吾尔自治区", "宁夏回族自治区", "甘肃省",
            "黑龙江省", "青海省",
        ],
        "score": [
            100.00, 96.75, 87.65, 86.27, 80.94,
            67.31, 58.14, 56.16, 43.39, 40.52,
            38.0, 35.0, 33.0, 30.0, 28.0,
            26.0, 24.0, 22.0, 20.0, 19.0,
            18.0, 17.5, 17.0, 16.5, 16.0,
            15.5, 15.21, 12.80, 10.93,
            9.29, 0.00,
        ],
    })
    draw_ranking(fake, year=2024)
