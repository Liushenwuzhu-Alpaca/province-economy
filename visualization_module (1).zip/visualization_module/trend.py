"""
trend.py — 多年份得分趋势折线图

展示 3~5 年里各省综合得分的演变。
PPT 上常用：可看出哪些省份"逆袭"（上升），哪些"掉队"（下降）。

支持两种数据格式：
  a) 长表（推荐）：包含 ``province``, ``year``, ``score`` 三列
  b) 宽表：以省份为 index，年份为列
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Optional, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ._style import (
    PROVINCE_PALETTE,
    ensure_output_dir,
    setup_chinese_font,
)


def draw_trend(
    data: pd.DataFrame,
    provinces: Optional[Sequence[str]] = None,
    *,
    province_col: str = "province",
    year_col: str = "year",
    score_col: str = "score",
    output_dir: os.PathLike | str | None = None,
    title: str = "省域经济综合得分多年趋势",
    show_top_n: int = 5,
    show_bottom_n: int = 3,
) -> dict:
    """绘制多省份多年度得分趋势折线图。

    Parameters
    ----------
    data : pd.DataFrame
        长表 (province, year, score) 或 宽表 (index=province, columns=year)。
    provinces : list[str], optional
        要显示的省份。若 None：取最新年份得分前 ``show_top_n`` 名 + 后 ``show_bottom_n`` 名。
    show_top_n / show_bottom_n : int
        默认筛选规则：前 N 强 + 后 M 弱，便于呈现"两极分化"。

    Returns
    -------
    dict
        {"top_png": Path, "compare_png": Path|None}
    """
    setup_chinese_font()
    out_dir = ensure_output_dir(output_dir)

    # 1) 统一为长表 ---------------------------------------------------------
    df = _to_long_format(data, province_col, year_col, score_col)
    df = df.sort_values([province_col, year_col])

    years = sorted(df[year_col].unique())
    latest_year = years[-1]

    # 2) 选省份 -------------------------------------------------------------
    if provinces is None:
        latest = df[df[year_col] == latest_year].sort_values(score_col, ascending=False)
        top_provinces = latest.head(show_top_n)[province_col].tolist()
        bottom_provinces = latest.tail(show_bottom_n)[province_col].tolist()
        provinces = top_provinces + bottom_provinces
    else:
        provinces = list(provinces)

    # 3) 主图：多省份折线 ---------------------------------------------------
    main_png = _plot_trend(
        df,
        provinces,
        province_col=province_col,
        year_col=year_col,
        score_col=score_col,
        title=f"{title}（{years[0]}—{years[-1]}）",
        save_path=out_dir / "08_趋势图_多省份对比.png",
    )

    # 4) 副图：东中西部分组对比 --------------------------------------------
    compare_png = _plot_region_compare(
        df,
        province_col=province_col,
        year_col=year_col,
        score_col=score_col,
        save_path=out_dir / "09_趋势图_东中西部对比.png",
    )

    return {"top_png": main_png, "compare_png": compare_png}


# ---------------------------------------------------------------------------

def _to_long_format(
    data: pd.DataFrame,
    province_col: str,
    year_col: str,
    score_col: str,
) -> pd.DataFrame:
    """把宽表统一转成长表 (province, year, score)。"""
    if {province_col, year_col, score_col}.issubset(data.columns):
        out = data[[province_col, year_col, score_col]].copy()
        out[year_col] = out[year_col].astype(int)
        return out
    # 宽表：index = 省份，columns = 年份
    df = data.copy()
    if province_col in df.columns:
        df = df.set_index(province_col)
    df.index.name = province_col
    df.columns.name = year_col
    long = df.stack().reset_index()
    long.columns = [province_col, year_col, score_col]
    long[year_col] = long[year_col].astype(int)
    return long


def _plot_trend(
    df: pd.DataFrame,
    provinces: Sequence[str],
    *,
    province_col: str,
    year_col: str,
    score_col: str,
    title: str,
    save_path: Path,
) -> Path:
    fig, ax = plt.subplots(figsize=(12, 6.5))

    for i, province in enumerate(provinces):
        sub = df[df[province_col] == province].sort_values(year_col)
        if sub.empty:
            print(f"[trend] 警告：{province} 无数据，已跳过")
            continue
        color = PROVINCE_PALETTE[i % len(PROVINCE_PALETTE)]
        ax.plot(
            sub[year_col],
            sub[score_col],
            marker="o",
            linewidth=2.2,
            markersize=7,
            label=province,
            color=color,
        )
        # 起点和终点标注
        ax.text(
            sub[year_col].iloc[-1] + 0.05,
            sub[score_col].iloc[-1],
            f" {sub[score_col].iloc[-1]:.1f}",
            color=color,
            fontsize=9,
            va="center",
            weight="bold",
        )

    ax.set_xlabel("年份", fontsize=12)
    ax.set_ylabel("综合得分", fontsize=12)
    ax.set_title(title, fontsize=15, weight="bold", pad=15)
    ax.grid(alpha=0.35, linestyle="--")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(
        loc="center left",
        bbox_to_anchor=(1.01, 0.5),
        fontsize=11,
        frameon=False,
    )

    # 让 X 轴显示整年份
    years = sorted(df[year_col].unique())
    ax.set_xticks(years)
    ax.set_xticklabels([str(y) for y in years])

    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close(fig)
    print(f"[trend] PNG 已生成: {save_path}")
    return save_path


# 东、中、西部经济区划（国家统计局口径，简版）
EAST = {"北京市", "天津市", "河北省", "辽宁省", "上海市", "江苏省",
        "浙江省", "福建省", "山东省", "广东省", "海南省"}
CENTRAL = {"山西省", "吉林省", "黑龙江省", "安徽省", "江西省", "河南省", "湖北省", "湖南省"}
WEST = {"内蒙古自治区", "广西壮族自治区", "重庆市", "四川省", "贵州省", "云南省",
        "西藏自治区", "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区"}


def _classify_region(province: str) -> str:
    if province in EAST:
        return "东部"
    if province in CENTRAL:
        return "中部"
    if province in WEST:
        return "西部"
    return "其他"


def _plot_region_compare(
    df: pd.DataFrame,
    *,
    province_col: str,
    year_col: str,
    score_col: str,
    save_path: Path,
) -> Optional[Path]:
    df = df.copy()
    df["region"] = df[province_col].map(_classify_region)
    df = df[df["region"] != "其他"]

    if df.empty:
        return None

    grouped = df.groupby(["region", year_col])[score_col].mean().reset_index()

    fig, ax = plt.subplots(figsize=(11, 6))
    region_colors = {"东部": "#b8311a", "中部": "#e89c5f", "西部": "#4a7ab8"}
    for region in ["东部", "中部", "西部"]:
        sub = grouped[grouped["region"] == region].sort_values(year_col)
        if sub.empty:
            continue
        ax.plot(
            sub[year_col], sub[score_col],
            marker="o", linewidth=2.6, markersize=9,
            label=region, color=region_colors[region],
        )
        ax.fill_between(sub[year_col], sub[score_col], alpha=0.08, color=region_colors[region])

    ax.set_xlabel("年份", fontsize=12)
    ax.set_ylabel("区域平均综合得分", fontsize=12)
    ax.set_title("东中西部经济综合竞争力区域均值趋势对比",
                 fontsize=15, weight="bold", pad=15)
    ax.grid(alpha=0.35, linestyle="--")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(loc="best", fontsize=12, frameon=True, framealpha=0.9)

    years = sorted(grouped[year_col].unique())
    ax.set_xticks(years)
    ax.set_xticklabels([str(y) for y in years])

    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close(fig)
    print(f"[trend] PNG 已生成: {save_path}")
    return save_path


if __name__ == "__main__":
    # 自测
    rng = np.random.default_rng(0)
    provinces_demo = [
        "广东省", "上海市", "北京市", "浙江省", "江苏省",
        "山东省", "四川省", "贵州省", "甘肃省", "青海省",
    ]
    rows = []
    for p in provinces_demo:
        base = rng.uniform(20, 100)
        for y in [2020, 2021, 2022, 2023, 2024]:
            rows.append({
                "province": p, "year": y,
                "score": max(0, base + rng.normal(0, 5) + (y - 2020) * rng.uniform(-2, 3)),
            })
    long_df = pd.DataFrame(rows)
    draw_trend(long_df)
